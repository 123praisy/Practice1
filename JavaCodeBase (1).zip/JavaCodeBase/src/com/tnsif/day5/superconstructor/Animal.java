package com.tnsif.day5.superconstructor;

public class Animal {
	
	Animal(){
		System.out.println("Animal is created");
	}

}
