package com.tnsif.day5.supervariable;

public class TestSuper1 {
	
	public static void main(String args[]){  
		Dog d=new Dog();  
		d.printColor();  
	}

}
