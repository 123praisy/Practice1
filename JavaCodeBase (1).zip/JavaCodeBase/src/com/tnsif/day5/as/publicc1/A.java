package com.tnsif.day5.as.publicc1;

public class A {
	
	public void display() {
		System.out.println("Display public contents");
	}

}
