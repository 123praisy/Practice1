package com.tnsif.day5.as.privatte;

public class A {
	
	private void display() {
		System.out.println("Display TNS sessions");
	}

}
