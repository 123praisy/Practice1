package com.tnsif.day5.as.publicc2;

import com.tnsif.day5.as.publicc1.A;

public class B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a1 = new A();
		a1.display(); // Public scope anybody can access.

	}

}
