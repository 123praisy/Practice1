package com.tnsif.day4.inheritence.typesofinheritence;

public class SingleLevelA {
	
	public void display() {
		System.out.println("I am a method from class A");
	}

}
