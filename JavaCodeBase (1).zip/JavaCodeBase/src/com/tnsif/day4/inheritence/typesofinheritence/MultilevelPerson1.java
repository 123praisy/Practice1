package com.tnsif.day4.inheritence.typesofinheritence;

public class MultilevelPerson1 {
	
	String getName() {
		return "progrramerBay";
	}

}
