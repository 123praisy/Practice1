package com.tnsif.day4.inheritence.typesofinheritence;

public class HierarchialInheritenceC extends HierarchialInheritenceA{
	
	 public void show() {
		 System.out.println(" I am a method from class C");
	 }

}
