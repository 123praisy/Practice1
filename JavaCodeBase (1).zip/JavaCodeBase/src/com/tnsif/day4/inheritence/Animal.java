package com.tnsif.day4.inheritence;

public class Animal {
	
	String name;
	public void eat() {
		System.out.println("I can eat");
	}

}
