package com.tnsif.day4.encapsulation;

public class Main1 {
	
	public static void main(String[] args) {
		Car1 c1= new Car1();
		c1.speed=40;
	//	c1.doors="closed";
		System.out.println(c1.speed);
	
	}

}


