package com.smms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.smms.entities.Customer;
import com.smms.service.CustomerService;

@RestController
public class CustomerController {


	@Autowired
	private CustomerService customerService;
	
	@PostMapping("/customervalue")
	public Customer saveCustomer(@RequestBody Customer customer) {
		return customerService.saveCustomer(customer);
	}
	
	@GetMapping("/customervalue")
	public List<Customer> fetchCustomerList() {
        //LOGGER.info("Inside fetchDepartmentList of DepartmentController");
        return customerService.fetchCustomerList();
    }
    
	@GetMapping("/customervalue/{id}")
	public Customer fetchCustomerById(@PathVariable("id") Long customerId)
    {
		return customerService.fetchCustomerById(customerId);
    }

	@DeleteMapping("/customervalue/{id}")
    public String deleteDepartmentById(@PathVariable("id") Long customerId) {
        customerService.deleteCustomerById(customerId);
        return "The customer is deleted. Renew if needed.";
    }
    
    @PutMapping("/customervalue/{id}")
    public Customer updateCustomer(@PathVariable("id") Long customerId,
                                       @RequestBody Customer customer) {
        return customerService.updateCustomer(customerId,customer);
    }

}
